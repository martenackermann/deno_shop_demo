export interface Cart {
    id: number;
    items: CartItem[];
    active: number;
}