<template>
  <footer aria-labelledby="footer-heading" class="border-t border-gray-200 bg-white">
    <h2 id="footer-heading" class="sr-only">Footer</h2>
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div class="py-12 text-center">
        <p class="text-base text-gray-400">© 2024 Company, Inc. All rights reserved.</p>
      </div>
    </div>
  </footer>
</template>
