<template>
  <section aria-labelledby="products-heading" class="mt-8">
    <h2 id="products-heading" class="sr-only">Products</h2>
    <div class="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
      <div v-for="product in products" :key="product.id" >
        <a :href="'product/'+product.id" class="group relative">
          <img
              :src="product.imageSrc"
              :alt="product.imageAlt"
              class="w-3/4 mx-auto aspect-square rounded-lg object-cover group-hover:opacity-75 sm:aspect-[2/3]"
          />
          <div class="w-3/4 mt-3 mx-auto rounded-lg object-cover group-hover:opacity-75 text-base font-medium text-gray-900">
            <h3>{{ product.name }}</h3>
            <p>{{ product.price }}</p>
            <p class="mt-1 text-sm italic text-gray-500">{{ product.description }}</p>
          </div>
        </a>
        <div class="w-3/4 mt-3 mx-auto rounded-lg object-cover group-hover:opacity-75 text-base font-medium text-gray-900">
          <button
              v-if="isLoggedIn"
              @click.stop="editProduct(product.id)"
              class="bg-blue-500 text-white px-2 py-1 rounded"
          >
            Edit
          </button>
          <button
              v-if="isLoggedIn"
              @click="$emit('delete-product', product.id)"
              class="bg-red-500 text-white ml-2 px-2 py-1 rounded"
          >
            Delete
          </button>
        </div>

      </div>
    </div>
  </section>
</template>

<script setup>
import {computed} from "vue";
import router from "@/router";

const props = defineProps({
  products: Array,
});

const isLoggedIn = computed(() => {
  return !!localStorage.getItem('user');
});

const editProduct = (productId) => {
  router.push(`/product/update/${productId}`);
};
</script>
