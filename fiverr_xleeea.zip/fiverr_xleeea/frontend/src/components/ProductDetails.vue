<template>
  <main v-if="product">
    <!-- Product -->
    <div class="bg-white">
      <div class="max-w-full px-4 pb-24 pt-16 sm:px-6 sm:pb-32 sm:pt-24 lg:grid  lg:grid-cols-2 lg:gap-x-8 lg:px-8">
        <!-- Product details -->
        <div>
          <nav aria-label="Breadcrumb">
            <ol role="list" class="flex items-center space-x-2">
              <li v-for="(breadcrumb, breadcrumbIdx) in breadcrumbs" :key="breadcrumb.id">
                <div class="flex items-center text-sm">
                  <a :href="breadcrumb.href" class="font-medium text-gray-500 hover:text-gray-900">{{ breadcrumb.name }}</a>
                  <svg v-if="breadcrumbIdx !== breadcrumbs.length - 1" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" class="ml-2 size-5 shrink-0 text-gray-300">
                    <path d="M5.555 17.776l8-16 .894.448-8 16-.894-.448z" />
                  </svg>
                </div>
              </li>
            </ol>
          </nav>

          <div class="mt-4">
            <h1 class="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              <template v-if="isUpdating || isCreating">
                <label for="product-name" class="block text-sm font-medium text-gray-700">Product Name</label>
                <input v-model="product.name" class="border rounded p-2 w-full" />
              </template>
              <template v-else>
                {{ product.name }}
              </template>
            </h1>
          </div>

          <section aria-labelledby="information-heading" class="mt-4">
            <h2 id="information-heading" class="sr-only">Product information</h2>

            <div class="flex items-center">
              <p class="text-lg text-gray-900 sm:text-xl">
                <template v-if="isUpdating || isCreating">
                  <label for="product-price" class="block text-sm font-medium text-gray-700">Price</label>
                  <input v-model="product.price" class="border rounded p-2 w-full" />
                </template>
                <template v-else>
                  {{ product.price }}
                </template>
              </p>

              <div class="ml-4 border-l border-gray-300 pl-4">
                <h2 class="sr-only">Reviews</h2>
                <div class="flex items-center">
                  <div>
                    <div class="flex items-center">
                      <StarIcon v-for="rating in [0, 1, 2, 3, 4]" :key="rating" :class="[reviews.average > rating ? 'text-yellow-400' : 'text-gray-300', 'size-5 shrink-0']" aria-hidden="true" />
                    </div>
                    <p class="sr-only">{{ reviews.average }} out of 5 stars</p>
                  </div>
                  <p class="ml-2 text-sm text-gray-500">{{ reviews.totalCount }} reviews</p>
                </div>
              </div>
            </div>

            <div class="mt-4 space-y-6">
              <template v-if="isUpdating || isCreating">
                <label for="product-description" class="block text-sm font-medium text-gray-700">Description</label>
                <textarea v-model="product.description" class="border rounded p-2 w-full"></textarea>
              </template>
              <template v-else>
                <p class="text-base text-gray-500">{{ product.description }}</p>
              </template>
            </div>

            <div class="mt-4 space-y-6">
              <template v-if="isUpdating || isCreating">
                <label for="product-details" class="block text-sm font-medium text-gray-700">Details</label>
                <textarea v-model="product.details" class="border rounded p-2 w-full"></textarea>
              </template>
              <template v-else>
                <p class="text-base text-gray-500">{{ product.details }}</p>
              </template>
            </div>

            <div class="mt-4 space-y-6">
              <template v-if="isUpdating || isCreating">
                <label for="product-taste-description" class="block text-sm font-medium text-gray-700">Taste Description</label>
                <textarea v-model="product.tasteDescription" class="border rounded p-2 w-full"></textarea>
              </template>
              <template v-else>
                <p class="text-base text-gray-500">{{ product.tasteDescription }}</p>
              </template>
            </div>

            <div class="mt-4 space-y-6">
              <template v-if="isUpdating || isCreating">
                <label for="product-ingredients" class="block text-sm font-medium text-gray-700">Ingredients</label>
                <input v-model="product.ingredients" class="border rounded p-2 w-full">
              </template>
              <template v-else>
                <p class="text-base text-gray-500">{{ product.ingredients }}</p>
              </template>
            </div>

            <div class="mt-4 space-y-6">
              <template v-if="isUpdating || isCreating">
                <label for="product-image-src" class="block text-sm font-medium text-gray-700">Image Source</label>
                <input v-model="product.imageSrc" class="border rounded p-2 w-full">
              </template>
            </div>
            <div class="mt-4 space-y-6">
              <template v-if="isUpdating || isCreating">
                <label for="product-country-of-origin" class="block text-sm font-medium text-gray-700">Country of Origin</label>
                <input v-model="product.countryOfOrigin" class="border rounded p-2 w-full">
              </template>
              <template v-else>
                <p class="text-base text-gray-500">{{ product.countryOfOrigin }}</p>
              </template>
            </div>

            <div class="mt-6 flex items-center">
              <CheckIcon class="size-5 shrink-0 text-green-500" aria-hidden="true" />
              <p class="ml-2 text-sm text-gray-500">In stock and ready to ship</p>
            </div>
          </section>
        </div>
        <!-- Product image -->
        <div class="lg:col-start-2 lg:row-span-2 lg:mt-0 lg:self-center">
          <img :src="product?.imageSrc" :alt="product.imageAlt" class="aspect-square w-full rounded-lg object-cover" />
        </div>

        <!-- Product form -->
        <div class="mt-10 lg:col-start-1 lg:row-start-2 lg:max-w-lg lg:self-start">
          <section aria-labelledby="options-heading">
            <h2 id="options-heading" class="sr-only">Product options</h2>
            <form @submit.prevent="isUpdating ? saveChanges() : isCreating ? createProduct() : addToBag()">
              <div class="mt-10">
                <button
                    v-if="!isCreating"
                    type="submit"
                    :disabled="isUpdating"
                    class="flex w-full items-center justify-center rounded-md border border-transparent bg-indigo-600 px-8 py-3 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-50"
                >
                  Add to bag
                </button>
                <button
                    v-if="isUpdating"
                    type="button"
                    @click="saveChanges"
                    class="flex w-full items-center justify-center rounded-md border border-transparent bg-green-600 px-8 py-3 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 focus:ring-offset-gray-50 mt-4"
                >
                  Save Changes
                </button>
                <button
                    v-if="isCreating"
                    type="button"
                    @click="createProduct"
                    class="flex w-full items-center justify-center rounded-md border border-transparent bg-blue-600 px-8 py-3 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-gray-50 mt-4"
                >
                  Create
                </button>
              </div>
              <div class="mt-6 text-center">
                <a href="#" class="group inline-flex text-base font-medium">
                  <ShieldCheckIcon class="mr-2 size-6 shrink-0 text-gray-400 group-hover:text-gray-500" aria-hidden="true" />
                  <span class="text-gray-500 hover:text-gray-700">Lifetime Guarantee</span>
                </a>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>

    <!-- Details section -->
    <!-- Policies section -->
    <div class="mt-16 lg:mt-24">
      <h2 id="policy-heading" class="sr-only">Our policies</h2>
      <div class="grid grid-cols-1 gap-y-12 sm:grid-cols-2 sm:gap-x-6 lg:grid-cols-4 lg:gap-x-8">
        <div v-for="policy in policies" :key="policy.name">
          <img :src="policy.imageSrc" alt="" class="h-24 w-auto" />
          <h3 class="mt-6 text-base font-medium text-gray-900">{{ policy.name }}</h3>
          <p class="mt-3 text-base text-gray-500">{{ policy.description }}</p>
        </div>
      </div>
    </div>
  </main>
</template>

<script setup>
import {ref, onMounted, watch} from 'vue';
import {useRoute} from 'vue-router';
import {CheckIcon, StarIcon} from '@heroicons/vue/20/solid';
import {ShieldCheckIcon} from '@heroicons/vue/24/outline';
import {toRaw} from 'vue';
import router from "@/router";


const props = defineProps({
  activeCart: Object,
  isUpdating: Boolean,
  isCreating: Boolean,
});

const route = useRoute();
const product = ref(props.isCreating ? {
  name: '',
  price: '',
  description: '',
  details: '',
  tasteDescription: '',
  ingredients: '',
  imageSrc: '',
  countryOfOrigin: ''
} : null);

const newCommentText = ref('');
const productName = ref(null);
const emit = defineEmits(['refresh-cart']);

const productId = route.params.id;
const href = ref(`http://localhost:8080/product/${productId}`);


const activeCartNew = ref({
  id: props.activeCart?.id || null,
  items: props.activeCart ? props.activeCart.items : [],
  active: props.activeCart?.active || 0,
});

const createProduct = async () => {
  try {
    const response = await fetch('http://localhost:8000/products/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(product.value),
    });

    if (response.ok) {
      router.push('/');
    } else {
      console.error('Failed to create product');
    }
  } catch (error) {
    console.error('Error creating product:', error);
  }
};

const fetchProductDetails = async () => {
  const productId = route.params.id;
  try {
    const response = await fetch(`http://localhost:8000/products/${productId}`);
    const data = await response.json();
    product.value = data;
    productName.value = product.value.name;
  } catch (error) {
    console.error('Error fetching product details:', error);
  }
};



const addToBag = async () => {
  try {
    const productValue = toRaw(product.value); // Unwrap proxy

    // Ensure items array is initialized
    if (!activeCartNew.value.items) {
      activeCartNew.value.items = [];
    }
    const cartItems = toRaw(activeCartNew.value.items);

    const existingItem = cartItems.find(item => Number(item.id) === Number(productValue.id));

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      activeCartNew.value.items.push({...productValue, quantity: 1});
    }

    const response = await fetch('http://localhost:8000/shoppingCarts', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(activeCartNew.value),
    });

    emit('refresh-cart', true);
  } catch (error) {
    console.error('Error adding product to cart:', error);
  }
};

const saveChanges = async () => {
  try {
    const productId = route.params.id;
    const response = await fetch(`http://localhost:8000/products/${productId}/update`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(product.value),
    });

    if (response.ok) {
      router.push('/');
    } else {
      console.error('Failed to update product');
    }
  } catch (error) {
    console.error('Error updating product:', error);
  }
};

const addComment = async () => {
  const comment = {
    text: newCommentText.value,
    author: 'Anonymous', // This can be enhanced with user authentication
  };

  try {
    const productId = route.params.id;
    await fetch(`http://localhost:8000/products/${productId}/comments`, {
      method: 'POST',
      body: JSON.stringify(comment),
      headers: {
        'Content-Type': 'application/json',
      },
    });

    product.value.comments.push(comment);
    newCommentText.value = '';
  } catch (error) {
    console.error('Error adding comment:', error);
  }
};


const breadcrumbs = {
  1: {id: 1, name: "Products", href: "/"},
  2: {id: 2, name: productName, href: href.value}
};

const policies = [
  {
    name: 'Free delivery all year long',
    description: 'Name another place that offers year long free delivery? We’ll be waiting. Order now and you’ll get delivery absolutely free.',
    imageSrc: 'https://tailwindui.com/plus/img/ecommerce/icons/icon-delivery-light.svg',
  },
  {
    name: '24/7 Customer Support',
    description: 'Or so we want you to believe. In reality our chat widget is powered by a naive series of if/else statements that churn out canned responses. Guaranteed to irritate.',
    imageSrc: 'https://tailwindui.com/plus/img/ecommerce/icons/icon-chat-light.svg',
  },
  {
    name: 'Fast Shopping Cart',
    description: "Look at the cart in that icon, there's never been a faster cart. What does this mean for the actual checkout experience? I don't know.",
    imageSrc: 'https://tailwindui.com/plus/img/ecommerce/icons/icon-fast-checkout-light.svg',
  },
  {
    name: 'Gift Cards',
    description: "We sell these hoping that you will buy them for your friends and they will never actually use it. Free money for us, it's great.",
    imageSrc: 'https://tailwindui.com/plus/img/ecommerce/icons/icon-gift-card-light.svg',
  },
];

const reviews = {
  average: 4,
  totalCount: 1624,
  counts: [
    {rating: 5, count: 1019},
    {rating: 4, count: 162},
    {rating: 3, count: 97},
    {rating: 2, count: 199},
    {rating: 1, count: 147},
  ],
  featured: [
    {
      id: 1,
      rating: 5,
      content: `
        <p>This is the bag of my dreams. I took it on my last vacation and was able to fit an absurd amount of snacks for the many long and hungry flights.</p>
      `,
      author: 'Emily Selman',
      avatarSrc: 'https://images.unsplash.com/photo-1502685104226-ee32379fefbe?ixlib=rb-=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=8&w=256&h=256&q=80',
    },
  ],
};

onMounted(async () => {
  if (!props.isCreating) {
    await fetchProductDetails();
  }
});
</script>