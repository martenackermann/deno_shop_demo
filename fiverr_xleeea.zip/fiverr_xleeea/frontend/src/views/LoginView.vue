<template>
  <LoginComponent></LoginComponent>
</template>

<script setup lang="ts">
import LoginComponent from "@/components/LoginComponent.vue";
</script>