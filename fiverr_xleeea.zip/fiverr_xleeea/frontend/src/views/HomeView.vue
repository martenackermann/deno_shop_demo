<template>
  <div>
    <!-- Top Bar (Global header/navigation) -->
    <TopBar />

    <!-- Filters and Sort Menu Section -->
    <div class="bg-gray-100">
      <div class="flex mx-auto px-4 py-2">
      <div class="h-full w-1/4 mr-4"><span class="sr-only">Platz für Filter</span></div>

        <!-- Product Grid Section -->
        <ProductGrid class="w-full" @delete-product="deleteProduct" :products="products" />
      </div>
    </div>

    <!-- Footer Section -->
    <SiteFooter />
  </div>
</template>

<script setup>
import TopBar from "@/components/TopBar.vue";
import ProductGrid from "@/components/ProductGrid.vue";
import SiteFooter from "@/components/SiteFooter.vue";

import { ref, onMounted } from "vue";

const products = ref([]);
const deleteProduct = async (productId) => {
  try {
    await fetch(`http://localhost:8000/products/${productId}`, {
      method: 'DELETE'
    });
    products.value = products.value.filter(product => product.id !== productId);
  } catch (error) {
    console.error("Error deleting product:", error);
  }
};
onMounted(async () => {
  try {
    const response = await fetch("http://localhost:8000/products");
    products.value = await response.json();
  } catch (error) {
    console.error("Error fetching products:", error);
  }
});
</script>
