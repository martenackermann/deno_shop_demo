<template>
  <div>
    <!-- Top Bar (Global header/navigation) -->
    <TopBar />

    <!-- Filters and Sort Menu Section -->
    <div class="bg-gray-100">
      <div class="flex mx-auto px-4 py-2">
        <CheckoutComponent class="w-full" v-if="activeCart" :active-cart="activeCart"></CheckoutComponent>
      </div>
    </div>

    <!-- Footer Section -->
    <SiteFooter />
  </div>
</template>

<script setup>
import TopBar from "@/components/TopBar.vue";
import SiteFooter from "@/components/SiteFooter.vue";
import CheckoutComponent from "@/components/CheckoutComponent.vue";
import {onMounted, ref} from "vue";

const activeCart = ref();
const fetchActiveCart = async () => {
  try {
    const response = await fetch('http://localhost:8000/shoppingCarts/active');
    activeCart.value = await response.json();
  } catch (error) {
    console.error('Error fetching active cart:', error);
  }
};

onMounted(async () => {
  await fetchActiveCart();
});
</script>
