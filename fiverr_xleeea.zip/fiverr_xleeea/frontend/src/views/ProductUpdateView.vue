<template>
  <div>
    <!-- Top Bar (Global header/navigation) -->
    <TopBar @active-cart="getActiveCart" :refresh-cart="refreshCart" @cart-updated="resetCartUpdate" />

    <!-- Filters and Sort Menu Section -->
    <div class="bg-gray-100">
      <div class="flex mx-auto px-4 py-2">
        <ProductDetails v-if="activeCart" :activeCart="activeCart" @refresh-cart="refreshCarts" :is-updating="true"></ProductDetails>
      </div>
    </div>

    <!-- Footer Section -->
    <SiteFooter />
  </div>
</template>

<script setup>
import TopBar from "@/components/TopBar.vue";
import SiteFooter from "@/components/SiteFooter.vue";
import ProductDetails from "@/components/ProductDetails.vue";
import {onMounted, ref} from "vue";

const activeCart = ref(null);
const refreshCart = ref(false);
const emit = defineEmits(["refresh-cart"]);
const getActiveCart = async () => {
  try {
    const response = await fetch('http://localhost:8000/shoppingCarts/active');
    const data = await response.json();
    activeCart.value = data;
    emit("refresh-cart", data);
  } catch (error) {
    console.error('Error fetching active cart:', error);
  }
};
const refreshCarts = async (value) => {
  refreshCart.value = value;
};
function resetCartUpdate(){
  refreshCart.value = false;
}


onMounted(async () => {
  await getActiveCart();
});
</script>