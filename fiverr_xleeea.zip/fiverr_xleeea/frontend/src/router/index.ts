import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router';
import Home from '../views/HomeView.vue';
import Login from '../views/LoginView.vue';
import ProductDetailView from "@/views/ProductDetailView.vue";
import CheckoutView from "@/views/CheckoutView.vue";
import ProductUpdateView from "@/views/ProductUpdateView.vue";
import ProductCreateView from "@/views/ProductCreateView.vue";

const routes: Array<RouteRecordRaw> = [
  { path: '/', component: Home },
  { path: '/checkout', component: CheckoutView },
  {
    path: '/product/:id',
    name: 'ProductDetails',
    component: ProductDetailView,
    props: true, // This passes the route params as props to the component
  },
  {
    path: '/product/create',
    name: 'ProductCreate',
    component: ProductCreateView,
    meta: { requiresAuth: true },
  },
  {
    path: '/product/update/:id',
    name: 'ProductUpdate',
    component: ProductUpdateView,
    props: true,
    meta: { requiresAuth: true },
  },
  { path: '/login', component: Login },
  // { path: '/product/create', component: ProductCreateEdit, meta: { requiresAuth: true } },
  // { path: '/product/edit/:id', component: ProductCreateEdit, meta: { requiresAuth: true } },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

// Global guard for authentication
router.beforeEach((to, from, next) => {
  const isAuthenticated = localStorage.getItem('user') !== null;

  if (to.matched.some(record => record.meta.requiresAuth) && !isAuthenticated) {
    next('/login');
  } else {
    next();
  }
});

export default router;
