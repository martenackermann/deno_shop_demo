/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './src/**/*.{vue,ts,js}',  // Add all Vue/TS/JS files for purging
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
